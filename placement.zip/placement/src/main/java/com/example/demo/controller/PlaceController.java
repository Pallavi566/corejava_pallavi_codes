package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Placement;
import com.example.demo.service.PlacementService;

@RestController
public class PlaceController {
	
	@Autowired
	public PlacementService pser;
	
	@PostMapping("/addplace")
	public Placement regPlacement(@RequestBody Placement place)
	{
		return pser.addPlacement(place);
		
	}
	
	@GetMapping ("/getplace")
	public List<Placement> getPlace()
	{
		return pser.getPlacement();
	}
	
	@DeleteMapping("/deleteplace/{id}")
	public void deletePlacement(@PathVariable int id)
	{
		pser.deletePlacement(id);
	}
	
	@PostMapping("/updateplace")
	public Placement updatePlacement(@RequestBody Placement place)
	{
		return pser.updatePlacement(place);
	}
}
