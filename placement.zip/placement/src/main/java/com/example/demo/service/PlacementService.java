package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Placement;
import com.example.demo.repository.PlaceRepository;


@Service
public class PlacementService {
	
	@Autowired
	public PlaceRepository prepo;
	
	public Placement addPlacement(Placement place)
	{
		return prepo.save(place);
	}	
	
	public List<Placement> getPlacement()
	{
		return prepo.findAll();
	}
	
	public void deletePlacement(Integer id)
	{
		prepo.deleteById(id);
	}
	
	public Placement updatePlacement(Placement place)
	{
		Integer placeid = place.getPid();
		Placement place1 = prepo.findById(placeid).get();
		place1.setPname(place.getPname());
		return prepo.save(place1);
		
	}
	
}
